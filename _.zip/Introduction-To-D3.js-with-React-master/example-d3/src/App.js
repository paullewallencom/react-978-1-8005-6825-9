import React, { Component } from 'react';
import ChartWrapper from './ChartWrapper';

class App extends Component {
  render() {
    return (
      <div className="App">
        <ChartWrapper />
      </div>
    );
  }
}

export default App;